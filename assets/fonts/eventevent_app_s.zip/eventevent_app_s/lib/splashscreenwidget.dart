
import 'package:eventevent_app_s/splashscreenwidget_animation1.dart';
import 'package:eventevent_app_s/values.dart';
import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';


class SPLASHSCREENWidget extends StatefulWidget {
  
  @override
  State<StatefulWidget> createState() => _SPLASHSCREENWidgetState();
}


class _SPLASHSCREENWidgetState extends State<SPLASHSCREENWidget> with SingleTickerProviderStateMixin {
  AnimationController logoPng01ImageAnimationController;
  
  @override
  void initState() {
  
    super.initState();
    this.logoPng01ImageAnimationController = AnimationController(duration: Duration(milliseconds: 450), vsync: this);
  }
  
  @override
  void dispose() {
  
    super.dispose();
    this.logoPng01ImageAnimationController.dispose();
  }
  
  void startAnimationOne() => this.logoPng01ImageAnimationController.forward();
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 0, 223, 146),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 208,
              height: 36,
              child: SPLASHSCREENWidgetAnimation1(
                animationController: this.logoPng01ImageAnimationController,
                child: Image.asset(
                  "assets/images/logo-png-01.png",
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}